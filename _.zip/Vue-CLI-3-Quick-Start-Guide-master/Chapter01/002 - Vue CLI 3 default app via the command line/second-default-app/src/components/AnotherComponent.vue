<template>
  <div>
    Just some example text.
  </div>
</template>

<script>
export default {
  name: 'AnotherComponent'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
div {
  font-size: 100px;
}
</style>
