<template>
	<div>
		<h1>What's up, Vue CLI 3?</h1>
		<hr>
	</div>
</template>