// add up 2 numbers
console.log(2+2);