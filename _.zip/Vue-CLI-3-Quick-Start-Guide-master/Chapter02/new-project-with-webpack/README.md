Get started with the following command

npm install