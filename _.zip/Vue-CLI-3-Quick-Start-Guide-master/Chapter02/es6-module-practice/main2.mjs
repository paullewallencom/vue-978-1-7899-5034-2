import returnWhatever from './whatever2';

returnWhatever();