let whatever = require('./whatever');

whatever.returnWhatever();