let CustomArticle = Vue.component('custom-article', {
    template: `
    <article>
    Our own custom article component!
    </article>`
})

export default CustomArticle;