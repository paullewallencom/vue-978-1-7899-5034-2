<template>
    <div id="entryPoint">
        <article>
            Our own custom article component!
        </article>
    </div>
</template>