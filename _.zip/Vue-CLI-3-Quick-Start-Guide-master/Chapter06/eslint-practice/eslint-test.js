function aFunction(a) 
{
    console.log(a, b);

}





